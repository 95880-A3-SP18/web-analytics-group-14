# Django Starter Project

Documentation for this project can be found here <https://drk-data-science.github.io/django-starter/>
