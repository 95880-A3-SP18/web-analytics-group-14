inforscraper.py:

Scraped Market of different cryptocurrencies to a .csv file into download folder;

Scraped Bit Coin markets info to a .csv file into download folder.